# Match Call — World Cup 2026

Website muujiya natiijooyinka World Cup 2026 iyo saadaalka gaarka ah ee isticmaalaha.

## Sida loo isticmaalo (local)

1. Ku rakib Node.js (hal mar) haddii aanad hore u lahayn: https://nodejs.org
2. Furfur terminal-ka folder-kan gudihiisa, kadibna orod:

```bash
npm install
npm run dev
```

3. Fur browser-ka, tag ciwaanka lagu muujiyay terminal-ka (sida `http://localhost:5173`).

## Sida loogu daabaco Internet-ka (deploy)

Habka ugu fudud waa **Vercel** ama **Netlify** — labaduba bilaash ah.

### Vercel (talo la siiyay)

1. Aad https://vercel.com oo ku gal (sign up) email ama GitHub.
2. Rakib Vercel CLI: `npm install -g vercel`
3. Folder-kan gudihiisa orod: `vercel`
4. Raac su'aalaha (deploy hal mar ayaa ku filan default settings-ka).
5. Vercel wuxuu ku siin doonaa link (URL) ah oo website-kaagu ku noolyahay online.

**AMA** si aan CLI loo isticmaalin:
1. Soo geli koodhkan GitHub repo cusub.
2. Tag vercel.com → "Add New Project" → xulo repo-gaaga → "Deploy".

### Netlify (ikhtiyaar kale)

1. Aad https://netlify.com oo ku gal.
2. Orod: `npm run build` (waxay abuuraysaa folder `dist/`).
3. Jiid oo ku tuur (drag & drop) folder-ka `dist` bogga Netlify ee "Deploy manually".

## Xogta ciyaaraha

Xogta natiijooyinka (`src/App.jsx` gudihiisa, array-ga `MATCHES`) waa xog la soo qaaday wakhtiga la dhisayay website-ka. Si xogtu had iyo jeer u cusboonaato, waxaad u baahan tahay:
- In aad si joogto ah u cusboonaysiiso array-ga `MATCHES` adigoo isticmaalaya xog-bixiye (API) sida SportRadar ama API-Football, AMA
- In aad ii soo weydiiso in aan xogta cusbooneysiiyo mar kasta oo aad rabto.

## Saadaalka isticmaalaha

Saadaalka waxa lagu kaydiyaa browser-ka isticmaalaha (`localStorage`) — waxay ku sii jirayaan kaliya aaladdaas iyo browser-kaas gudihiisa. Haddii aad rabto in saadaalka la kaydiyo si guud (dhammaan isticmaalayaasha, dhammaan aaladaha), waxaad u baahan tahay backend/database — waan ku caawin karaa haddii aad taas rabto.
