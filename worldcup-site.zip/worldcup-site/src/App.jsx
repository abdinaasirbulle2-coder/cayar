import { useState, useMemo } from "react";

// ---- Real match data (fetched from live sports feed) ----
const MATCHES = [
  { id: "53452547", status: "final", home: "Netherlands", away: "Morocco", homeAb: "NED", awayAb: "MAR", hs: 1, as: 1, time: "Jun 30, 4:00 AM" },
  { id: "53452561", status: "final", home: "Ivory Coast", away: "Norway", homeAb: "CIV", awayAb: "NOR", hs: 1, as: 2, time: "Jun 30, 8:00 PM" },
  { id: "53452543", status: "final", home: "France", away: "Sweden", homeAb: "FRA", awayAb: "SWE", hs: 3, as: 0, time: "Jul 1, 12:00 AM" },
  { id: "53452563", status: "final", home: "Mexico", away: "Ecuador", homeAb: "MEX", awayAb: "ECU", hs: 2, as: 0, time: "Jul 1, 5:00 AM" },
  { id: "53452565", status: "final", home: "England", away: "Congo DR", homeAb: "ENG", awayAb: "COD", hs: 2, as: 1, time: "Jul 1, 7:00 PM" },
  { id: "53452555", status: "final", home: "Belgium", away: "Senegal", homeAb: "BEL", awayAb: "SEN", hs: 3, as: 2, time: "Jul 1, 11:00 PM" },
  { id: "53452553", status: "final", home: "USA", away: "Bosnia and Herzegovina", homeAb: "USA", awayAb: "BIH", hs: 2, as: 0, time: "Jul 2, 3:00 AM" },
  { id: "53452551", status: "final", home: "Spain", away: "Austria", homeAb: "ESP", awayAb: "AUT", hs: 3, as: 0, time: "Jul 2, 10:00 PM" },
  { id: "53452549", status: "final", home: "Portugal", away: "Croatia", homeAb: "POR", awayAb: "CRO", hs: 2, as: 1, time: "Jul 3, 2:00 AM" },
  { id: "53452505", status: "final", home: "Switzerland", away: "Algeria", homeAb: "SUI", awayAb: "DZA", hs: 2, as: 0, time: "Jul 3, 6:00 AM" },
  { id: "53452503", status: "scheduled", home: "Australia", away: "Egypt", homeAb: "AUS", awayAb: "EGY", time: "Jul 3, 9:00 PM", prob: { home: 26.9, away: 39.7, draw: 33.4 } },
  { id: "53452569", status: "scheduled", home: "Argentina", away: "Cape Verde", homeAb: "ARG", awayAb: "CPV", time: "Jul 4, 1:00 AM", prob: { home: 85.3, away: 3.9, draw: 10.8 } },
  { id: "53452507", status: "scheduled", home: "Colombia", away: "Ghana", homeAb: "COL", awayAb: "GHA", time: "Jul 4, 4:30 AM", prob: { home: 68.1, away: 10.6, draw: 21.3 } },
  { id: "53452511", status: "scheduled", home: "Canada", away: "Morocco", homeAb: "CAN", awayAb: "MAR", time: "Jul 4, 8:00 PM", prob: { home: 18.9, away: 53.9, draw: 27.2 } },
  { id: "53452509", status: "scheduled", home: "Paraguay", away: "France", homeAb: "PAR", awayAb: "FRA", time: "Jul 5, 12:00 AM", prob: { home: 5.8, away: 81.2, draw: 13 } },
  { id: "53452517", status: "scheduled", home: "Brazil", away: "Norway", homeAb: "BRA", awayAb: "NOR", time: "Jul 5, 11:00 PM", prob: { home: 51.6, away: 22.8, draw: 25.6 } },
  { id: "53452519", status: "scheduled", home: "Mexico", away: "England", homeAb: "MEX", awayAb: "ENG", time: "Jul 6, 3:00 AM", prob: { home: 30.3, away: 39.6, draw: 30.1 } },
  { id: "53452513", status: "scheduled", home: "Portugal", away: "Spain", homeAb: "POR", awayAb: "ESP", time: "Jul 6, 10:00 PM", prob: { home: 23.5, away: 50.2, draw: 26.3 } },
  { id: "53452515", status: "scheduled", home: "USA", away: "Belgium", homeAb: "USA", awayAb: "BEL", time: "Jul 7, 3:00 AM", prob: { home: 36.5, away: 35.9, draw: 27.6 } },
];

const STORAGE_KEY = "wc-predictions-v1";

function loadPredictions() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function savePredictionsToStorage(predictions) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(predictions));
  } catch {
    // storage unavailable — predictions just won't persist
  }
}

export default function WorldCupPredictor() {
  const [predictions, setPredictions] = useState(() => loadPredictions());
  const [filter, setFilter] = useState("all");
  const [draft, setDraft] = useState({});
  const liveMatches = MATCHES.filter((m) => m.status === "inprogress");

  const savePrediction = (matchId, home, away) => {
    setPredictions((prev) => {
      const next = { ...prev, [matchId]: { home, away, lockedAt: Date.now() } };
      savePredictionsToStorage(next);
      return next;
    });
  };

  const clearPrediction = (matchId) => {
    setPredictions((prev) => {
      const next = { ...prev };
      delete next[matchId];
      savePredictionsToStorage(next);
      return next;
    });
  };

  const stats = useMemo(() => {
    let correct = 0, total = 0;
    MATCHES.forEach((m) => {
      if (m.status === "final" && predictions[m.id]) {
        total++;
        if (Number(predictions[m.id].home) === m.hs && Number(predictions[m.id].away) === m.as) {
          correct++;
        }
      }
    });
    return { correct, total };
  }, [predictions]);

  const visible = MATCHES.filter((m) => {
    if (filter === "final") return m.status === "final";
    if (filter === "scheduled") return m.status === "scheduled";
    return true;
  });

  return (
    <div style={styles.page}>
      <style>{fontImports}</style>
      <header style={styles.header}>
        <div style={styles.headerInner}>
          <div style={styles.brandRow}>
            <div style={styles.crest}>⚽</div>
            <div>
              <div style={styles.eyebrow}>2026 TOURNAMENT</div>
              <h1 style={styles.title}>MATCH CALL</h1>
            </div>
          </div>
          {stats.total > 0 && (
            <div style={styles.scoreboard}>
              <div style={styles.scoreboardLabel}>YOUR RECORD</div>
              <div style={styles.scoreboardValue}>
                {stats.correct} <span style={styles.scoreboardSlash}>/</span> {stats.total}
              </div>
            </div>
          )}
        </div>
      </header>

      {liveMatches.length > 0 ? (
        <div style={styles.liveBanner}>
          <span style={styles.liveDot} /> LIVE NOW — {liveMatches.length} match
          {liveMatches.length > 1 ? "es" : ""} in progress
        </div>
      ) : (
        <div style={styles.liveBannerIdle}>No live matches right now</div>
      )}

      <nav style={styles.tabs}>
        {[
          { key: "all", label: "All matches" },
          { key: "scheduled", label: "Upcoming" },
          { key: "final", label: "Results" },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setFilter(t.key)}
            style={{
              ...styles.tab,
              ...(filter === t.key ? styles.tabActive : {}),
            }}
          >
            {t.label}
          </button>
        ))}
      </nav>

      <main style={styles.main}>
        {visible.map((m) => {
          const pred = predictions[m.id];
          const isFinal = m.status === "final";
          const isLive = m.status === "inprogress";
          const isCorrect = isFinal && pred && Number(pred.home) === m.hs && Number(pred.away) === m.as;
          const d = draft[m.id] || { home: "", away: "" };

          return (
            <div key={m.id} style={styles.card}>
              <div style={styles.cardTop}>
                <span style={styles.matchTime}>{m.time}</span>
                <span
                  style={{
                    ...styles.statusPill,
                    ...(isFinal ? styles.statusPillFinal : isLive ? styles.statusPillOnAir : styles.statusPillLive),
                  }}
                >
                  {isFinal ? "FULL TIME" : isLive ? "● LIVE" : "KICKOFF PENDING"}
                </span>
              </div>

              <div style={styles.teamsRow}>
                <TeamBlock name={m.home} ab={m.homeAb} align="right" />
                <div style={styles.centerScore}>
                  {isFinal || isLive ? (
                    <div style={{ ...styles.finalScore, ...(isLive ? styles.liveScore : {}) }}>
                      {m.hs} <span style={styles.scoreDash}>–</span> {m.as}
                    </div>
                  ) : (
                    <div style={styles.vs}>VS</div>
                  )}
                </div>
                <TeamBlock name={m.away} ab={m.awayAb} align="left" />
              </div>

              {!isFinal && !isLive && m.prob && (
                <div style={styles.probRow}>
                  <ProbBar label={m.homeAb} pct={m.prob.home} />
                  <ProbBar label="DRAW" pct={m.prob.draw} muted />
                  <ProbBar label={m.awayAb} pct={m.prob.away} />
                </div>
              )}

              <div style={styles.stubDivider}>
                {Array.from({ length: 40 }).map((_, i) => (
                  <span key={i} style={styles.stubDot} />
                ))}
              </div>

              {!isFinal && !isLive ? (
                pred ? (
                  <div style={styles.stub}>
                    <div style={styles.stubLabel}>YOUR CALL</div>
                    <div style={styles.stubScore}>
                      {m.homeAb} {pred.home} – {pred.away} {m.awayAb}
                    </div>
                    <button onClick={() => clearPrediction(m.id)} style={styles.stubEdit}>
                      Change pick
                    </button>
                  </div>
                ) : (
                  <div style={styles.predictForm}>
                    <div style={styles.stubLabel}>MAKE YOUR CALL</div>
                    <div style={styles.predictInputs}>
                      <input
                        type="number"
                        min="0"
                        max="20"
                        placeholder="0"
                        value={d.home}
                        onChange={(e) =>
                          setDraft({ ...draft, [m.id]: { ...d, home: e.target.value } })
                        }
                        style={styles.scoreInput}
                        aria-label={`Predicted score for ${m.home}`}
                      />
                      <span style={styles.predictDash}>–</span>
                      <input
                        type="number"
                        min="0"
                        max="20"
                        placeholder="0"
                        value={d.away}
                        onChange={(e) =>
                          setDraft({ ...draft, [m.id]: { ...d, away: e.target.value } })
                        }
                        style={styles.scoreInput}
                        aria-label={`Predicted score for ${m.away}`}
                      />
                      <button
                        disabled={d.home === "" || d.away === "" || d.home === undefined || d.away === undefined}
                        onClick={() => savePrediction(m.id, d.home, d.away)}
                        style={{
                          ...styles.lockBtn,
                          ...(d.home === "" || d.away === "" || d.home === undefined || d.away === undefined
                            ? styles.lockBtnDisabled
                            : {}),
                        }}
                      >
                        Lock it in
                      </button>
                    </div>
                  </div>
                )
              ) : isFinal && pred ? (
                <div style={{ ...styles.stub, ...(isCorrect ? styles.stubCorrect : styles.stubMissed) }}>
                  <div style={styles.stubLabel}>{isCorrect ? "CALLED IT" : "YOUR CALL"}</div>
                  <div style={styles.stubScore}>
                    {m.homeAb} {pred.home} – {pred.away} {m.awayAb}
                  </div>
                  <div style={styles.stubResult}>{isCorrect ? "✓ Exact score" : "Missed"}</div>
                </div>
              ) : isLive && pred ? (
                <div style={styles.stub}>
                  <div style={styles.stubLabel}>YOUR CALL — locked, match in progress</div>
                  <div style={styles.stubScore}>
                    {m.homeAb} {pred.home} – {pred.away} {m.awayAb}
                  </div>
                </div>
              ) : (
                <div style={styles.noCall}>
                  {isLive ? "No prediction was made before kickoff" : "No prediction made before kickoff"}
                </div>
              )}
            </div>
          );
        })}
      </main>

      <footer style={styles.footer}>Scores update from live tournament data.</footer>
    </div>
  );
}

function TeamBlock({ name, ab, align }) {
  return (
    <div style={{ ...styles.teamBlock, textAlign: align, alignItems: align === "right" ? "flex-end" : "flex-start" }}>
      <div style={styles.teamAbbr}>{ab}</div>
      <div style={styles.teamName}>{name}</div>
    </div>
  );
}

function ProbBar({ label, pct, muted }) {
  return (
    <div style={styles.probItem}>
      <div style={styles.probTrack}>
        <div
          style={{
            ...styles.probFill,
            width: `${pct}%`,
            background: muted ? "#8a9a8f" : "#D4AF37",
          }}
        />
      </div>
      <div style={styles.probLabel}>
        {label} <span style={styles.probPct}>{pct.toFixed(0)}%</span>
      </div>
    </div>
  );
}

const fontImports = `
  @import url('https://fonts.googleapis.com/css2?family=Archivo+Black&family=Archivo:wght@400;500;600;700&family=DM+Mono:wght@400;500&display=swap');
  @keyframes pulse {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.4; transform: scale(0.8); }
  }
`;

const styles = {
  page: {
    minHeight: "100vh",
    background: "#0F3D2E",
    backgroundImage:
      "radial-gradient(circle at 50% 0%, #14503D 0%, #0F3D2E 55%, #0A2E22 100%)",
    fontFamily: "'Archivo', sans-serif",
    color: "#F4F1E8",
    paddingBottom: "3rem",
  },
  header: {
    borderBottom: "3px solid #D4AF37",
    background: "rgba(10, 46, 34, 0.6)",
    backdropFilter: "blur(6px)",
    position: "sticky",
    top: 0,
    zIndex: 10,
  },
  headerInner: {
    maxWidth: 720,
    margin: "0 auto",
    padding: "1.25rem 1.25rem",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: "0.75rem",
  },
  brandRow: { display: "flex", alignItems: "center", gap: "0.75rem" },
  crest: {
    width: 44,
    height: 44,
    borderRadius: "50%",
    background: "#D4AF37",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "1.3rem",
    flexShrink: 0,
  },
  eyebrow: {
    fontFamily: "'DM Mono', monospace",
    fontSize: "0.65rem",
    letterSpacing: "0.15em",
    color: "#D4AF37",
    marginBottom: "0.15rem",
  },
  title: {
    fontFamily: "'Archivo Black', sans-serif",
    fontSize: "1.5rem",
    letterSpacing: "0.02em",
    margin: 0,
  },
  scoreboard: {
    background: "#0A2E22",
    border: "1px solid #2A5D48",
    borderRadius: 6,
    padding: "0.4rem 0.9rem",
    textAlign: "center",
  },
  scoreboardLabel: {
    fontFamily: "'DM Mono', monospace",
    fontSize: "0.55rem",
    letterSpacing: "0.1em",
    color: "#8FBFA5",
  },
  scoreboardValue: {
    fontFamily: "'Archivo Black', sans-serif",
    fontSize: "1.15rem",
    color: "#D4AF37",
  },
  scoreboardSlash: { color: "#4A7060", fontWeight: 400 },
  liveBanner: {
    maxWidth: 720,
    margin: "1rem auto 0",
    padding: "0.6rem 1.25rem",
    display: "flex",
    alignItems: "center",
    gap: "0.5rem",
    fontFamily: "'DM Mono', monospace",
    fontSize: "0.75rem",
    letterSpacing: "0.05em",
    color: "#F4F1E8",
  },
  liveBannerIdle: {
    maxWidth: 720,
    margin: "1rem auto 0",
    padding: "0.6rem 1.25rem",
    fontFamily: "'DM Mono', monospace",
    fontSize: "0.72rem",
    color: "#6E8B7A",
    fontStyle: "italic",
  },
  liveDot: {
    width: 8,
    height: 8,
    borderRadius: "50%",
    background: "#E14D3A",
    display: "inline-block",
    animation: "pulse 1.4s infinite",
  },
  tabs: {
    maxWidth: 720,
    margin: "0 auto",
    display: "flex",
    gap: "0.5rem",
    padding: "1rem 1.25rem 0",
  },
  tab: {
    background: "transparent",
    border: "1px solid #2A5D48",
    color: "#B8CFC1",
    padding: "0.45rem 0.9rem",
    borderRadius: 20,
    fontFamily: "'Archivo', sans-serif",
    fontSize: "0.8rem",
    fontWeight: 600,
    cursor: "pointer",
  },
  tabActive: {
    background: "#D4AF37",
    borderColor: "#D4AF37",
    color: "#0A2E22",
  },
  main: {
    maxWidth: 720,
    margin: "0 auto",
    padding: "1.25rem",
    display: "flex",
    flexDirection: "column",
    gap: "1rem",
  },
  card: {
    background: "#F4F1E8",
    color: "#14251C",
    borderRadius: 10,
    padding: "1.1rem 1.2rem 1.3rem",
    boxShadow: "0 8px 24px rgba(0,0,0,0.25)",
  },
  cardTop: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "0.8rem",
  },
  matchTime: {
    fontFamily: "'DM Mono', monospace",
    fontSize: "0.7rem",
    color: "#5B6F63",
  },
  statusPill: {
    fontFamily: "'DM Mono', monospace",
    fontSize: "0.6rem",
    letterSpacing: "0.08em",
    padding: "0.2rem 0.55rem",
    borderRadius: 20,
  },
  statusPillFinal: { background: "#14251C", color: "#F4F1E8" },
  statusPillLive: { background: "#D4AF37", color: "#14251C" },
  statusPillOnAir: { background: "#E14D3A", color: "#F4F1E8" },
  teamsRow: {
    display: "grid",
    gridTemplateColumns: "1fr auto 1fr",
    alignItems: "center",
    gap: "0.75rem",
  },
  teamBlock: { display: "flex", flexDirection: "column" },
  teamAbbr: {
    fontFamily: "'Archivo Black', sans-serif",
    fontSize: "1.1rem",
    letterSpacing: "0.03em",
  },
  teamName: {
    fontSize: "0.7rem",
    color: "#5B6F63",
    marginTop: "0.1rem",
  },
  centerScore: { textAlign: "center", minWidth: 90 },
  finalScore: {
    fontFamily: "'Archivo Black', sans-serif",
    fontSize: "2.1rem",
  },
  scoreDash: { color: "#B7A15A" },
  liveScore: { color: "#C0392B" },
  vs: {
    fontFamily: "'DM Mono', monospace",
    fontSize: "0.85rem",
    color: "#8a9a8f",
    fontWeight: 500,
  },
  probRow: {
    display: "flex",
    gap: "0.6rem",
    marginTop: "1rem",
  },
  probItem: { flex: 1 },
  probTrack: {
    height: 5,
    background: "#E2DDCB",
    borderRadius: 3,
    overflow: "hidden",
    marginBottom: "0.3rem",
  },
  probFill: { height: "100%", borderRadius: 3 },
  probLabel: {
    fontFamily: "'DM Mono', monospace",
    fontSize: "0.62rem",
    color: "#5B6F63",
    textAlign: "center",
  },
  probPct: { color: "#14251C", fontWeight: 600 },
  stubDivider: {
    display: "flex",
    justifyContent: "space-between",
    margin: "1rem 0 0.9rem",
    overflow: "hidden",
  },
  stubDot: {
    width: 4,
    height: 4,
    borderRadius: "50%",
    background: "#D6D1BC",
    flexShrink: 0,
  },
  predictForm: {},
  stubLabel: {
    fontFamily: "'DM Mono', monospace",
    fontSize: "0.62rem",
    letterSpacing: "0.1em",
    color: "#8a9a8f",
    marginBottom: "0.5rem",
  },
  predictInputs: {
    display: "flex",
    alignItems: "center",
    gap: "0.5rem",
  },
  scoreInput: {
    width: 52,
    height: 44,
    fontFamily: "'Archivo Black', sans-serif",
    fontSize: "1.1rem",
    textAlign: "center",
    border: "2px solid #C9C2A5",
    borderRadius: 6,
    background: "#FFFDF6",
    color: "#14251C",
  },
  predictDash: { fontSize: "1.1rem", color: "#8a9a8f" },
  lockBtn: {
    marginLeft: "auto",
    background: "#14251C",
    color: "#F4F1E8",
    border: "none",
    borderRadius: 6,
    padding: "0.7rem 1.1rem",
    fontFamily: "'Archivo', sans-serif",
    fontWeight: 700,
    fontSize: "0.8rem",
    cursor: "pointer",
  },
  lockBtnDisabled: { opacity: 0.35, cursor: "not-allowed" },
  stub: {
    background: "#EDE8D5",
    borderRadius: 6,
    padding: "0.7rem 0.9rem",
    display: "flex",
    alignItems: "center",
    gap: "0.75rem",
    flexWrap: "wrap",
  },
  stubCorrect: { background: "#DCEFE0", border: "1px solid #6FAF82" },
  stubMissed: { background: "#F1E8E4", border: "1px solid #D6BBAF" },
  stubScore: {
    fontFamily: "'Archivo Black', sans-serif",
    fontSize: "1rem",
  },
  stubEdit: {
    marginLeft: "auto",
    background: "transparent",
    border: "none",
    color: "#5B6F63",
    textDecoration: "underline",
    fontSize: "0.75rem",
    cursor: "pointer",
    fontFamily: "'Archivo', sans-serif",
  },
  stubResult: {
    marginLeft: "auto",
    fontFamily: "'DM Mono', monospace",
    fontSize: "0.7rem",
    fontWeight: 600,
  },
  noCall: {
    fontFamily: "'DM Mono', monospace",
    fontSize: "0.72rem",
    color: "#8a9a8f",
    fontStyle: "italic",
  },
  footer: {
    textAlign: "center",
    marginTop: "1rem",
    fontFamily: "'DM Mono', monospace",
    fontSize: "0.65rem",
    color: "#5B7A69",
  },
};
